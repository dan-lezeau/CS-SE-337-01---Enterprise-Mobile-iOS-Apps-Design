//
//  RosterModel.swift
//  MU Football DL Roster List
//
//  Created by Daniel Lezeau on 9/29/26.
//

import Foundation

struct Athlete: Identifiable {
    
    // MARK: - properties
    let id: String
    let number: Int
    let firstName: String
    let lastName: String
    let position: String
    let height: String
    let weight: String
    var starter: Bool = false
    
}

struct AthletesModel {
    
    var athletes: [Athlete] = []
    
    static var exampleAthlete = Athlete(id: "001", number: 74, firstName: "Daniel", lastName: "Lezeau", position: "DL", height: "6'1", weight: "270lbs", starter: true)
    
    // MARK: - methods
    
    init() {
        
        athletes = [
            
            Athlete(id: "005", number: 4, firstName: "Hunter" , lastName: "Watson", position: "DL", height: "6'5", weight: "270lbs", starter: true),
            Athlete(id: "010", number: 8, firstName: "JJ", lastName: "Lewis", position: "DL", height: "6'3", weight: "280lbs", starter: true),
            Athlete(id: "053", number: 43, firstName: "Jake", lastName: "Davis",position: "DL", height: "6'3", weight: "240lbs", starter: true),
            Athlete(id: "054",number: 44, firstName: "Donovan", lastName: "Dyson", position: "DL", height: "6'2", weight: "235lbs", starter: true),
            Athlete(id: "062", number: 50, firstName: "Avery", lastName: "Barnes", position: "DL", height: "6'2", weight: "285lbs", starter: false),
            Athlete(id: "068",number: 56, firstName: "Khalil", lastName: "Sutton", position: "DL", height: "6'2", weight: "205lbs", starter: false),
            Athlete(id: "070", number: 58, firstName: "Mandel", lastName: "Pettiford Jr.", position: "DL", height: "6'1", weight: "285lbs",  starter: false),
            Athlete(id: "080", number: 68, firstName: "Aaron", lastName: "Loritts", position: "DL", height: "6'2", weight: "240lbs", starter: false),
            Athlete(id: "100", number: 89, firstName: "Donovan", lastName: "Rondeau Jr.", position: "DL", height: "6'3", weight: "235lbs", starter: false),
            Athlete(id: "101", number: 90, firstName: "Brendan", lastName: "Bigos", position: "DL", height: "6'3", weight: "290lbs", starter: true),
            Athlete(id: "102", number: 91, firstName: "Mason", lastName: "Triplin", position: "DL", height: "6'2", weight: "280lbs", starter: false),
            Athlete(id: "103" ,number: 92, firstName: "Bryce", lastName: "Rooks", position: "DL", height: "6'0", weight: "295lbs", starter: true),
            Athlete(id: "104" ,number: 93, firstName: "Keisean", lastName: "Johnson-Wilson", position: "DL", height:"6'2", weight: "295lbs", starter: true),
            Athlete(id: "105" ,number: 94, firstName: "Malachi", lastName: "Ramnath", position: "DL", height: "6'3", weight: "255lbs"),
            Athlete(id: "106",number: 95, firstName: "Johnny", lastName:  "Miles", position: "DL", height: "6'5", weight: "280lbs"),
            Athlete(id: "124",number: 96, firstName: "Sebastien", lastName: "Acheampong", position: "DL", height: "6'2", weight: "275lbs", starter: true),
            Athlete(id: "107",number: 97, firstName: "Rashee", lastName: "Bell", position: "DL", height: "6'3", weight: "260lbs"),
            Athlete(id: "108", number: 98, firstName: "Hugo", lastName: "Gil", position: "DL", height: "6'3", weight: "300lbs"),
            Athlete(id: "109",number: 99, firstName: "Jahide", lastName: "Lesaine Jr.", position: "DL", height: "6'3", weight: "260lbs", starter: true)
            
        ]
        print(athletes)
        
    }
    
    mutating func updateAthlete(number: Int) {
        if let findAthleteIdx = athletes.firstIndex(where: {$0.number == number}) {
            athletes[findAthleteIdx].starter.toggle()
            print (athletes)
        }
        
        
    }
    
    
}
    

//
//  AthleteRowView.swift
//  MU Football DL Roster List
//
//  Created by Daniel Lezeau on 10/1/26.
//

import SwiftUI

struct AthleteRowView: View {
    let athletes: Athlete
    
    let baseURL = "https://images.sidearmdev.com/resize?url=https%3a%2f%2fdxbhsrqyrr690.cloudfront.net%2fsidearm.nextgen.sites%2fmonmouthuni.sidearmsports.com%2fimages%2f2026%2f7%2f29%2fFB_Headshots_2026-"
    
    let endURL = ".jpg&width=300&type=webp"
    
    var body: some View {
        HStack (alignment: .top) {
            
            if athletes.id == "124" {
                    Image("Sebastien")
                    .resizable()
                    .scaledToFill()
                    .frame(width:100, height: 100)
                    .clipShape(RoundedRectangle(cornerRadius: 50))
            }
            
            else {
                let imageURL = URL(string: baseURL + String(athletes.id) + endURL)

                AsyncImage(url: imageURL) { phase in
                    if let image = phase.image {
                        image
                            .resizable()
                            .scaledToFill()
                            .frame(width:100, height: 100)
                            .clipShape(RoundedRectangle(cornerRadius: 50))
                    } else {
                        ProgressView()
                            .frame(width: 100, height: 100)
                    }
                    
                }
            }
            
            
            VStack (alignment:.leading) {
                Text("\(athletes.firstName) \(athletes.lastName)")
                    .font(.system(size: 20))
                Text(String(athletes.number))
                Text(athletes.position)
                Text(athletes.weight)
                
                    .font(Font.caption.bold())
                if athletes.starter {
                    Image(systemName: "s.circle.fill")
                }
            }
        }
    }
}

#Preview {
    let exampleAthlete = AthletesModel.exampleAthlete
    AthleteRowView(athletes: exampleAthlete)
    
}

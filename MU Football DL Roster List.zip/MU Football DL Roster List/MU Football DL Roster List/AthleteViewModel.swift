//
//  AthleteViewModel.swift
//  MU Football DL Roster List
//
//  Created by Daniel Lezeau on 10/1/26.
//

import SwiftUI

@Observable
class AthletesViewModel {
    
    var athletesModel = AthletesModel ()
    
    func updateAthlete(number: Int) {
        athletesModel.updateAthlete(number: number)
        
    }
}

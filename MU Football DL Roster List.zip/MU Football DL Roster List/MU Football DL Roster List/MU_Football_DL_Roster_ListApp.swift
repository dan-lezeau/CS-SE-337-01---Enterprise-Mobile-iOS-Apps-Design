//
//  MU_Football_DL_Roster_ListApp.swift
//  MU Football DL Roster List
//
//  Created by Daniel Lezeau on 9/29/26.
//

import SwiftUI

@main
struct MU_Football_DL_Roster_ListApp: App {
    var body: some Scene {
        WindowGroup {
            AthletesListView()
        }
    }
}

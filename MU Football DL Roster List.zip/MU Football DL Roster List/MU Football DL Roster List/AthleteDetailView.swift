//
//  AthleteDetailView.swift
//  MU Football DL Roster List
//
//  Created by Daniel Lezeau on 10/1/26.
//

import SwiftUI

struct AthleteDetailView: View {
    
    // data sent from calling view
    // @Binding refers to viewModel instantiated in parent view
    
    let selectedAthlete: Athlete
    @Binding var viewModel: AthletesViewModel
    
    // Local variable to track ToggleView status as Starter
    
    @State var isStarter: Bool
    
    let baseURL = "https://images.sidearmdev.com/resize?url=https%3a%2f%2fdxbhsrqyrr690.cloudfront.net%2fsidearm.nextgen.sites%2fmonmouthuni.sidearmsports.com%2fimages%2f2026%2f7%2f29%2fFB_Headshots_2026-"
    
    let endURL = ".jpg&width=300&type=webp"
    
    var body: some View {
        VStack {
            ZStack {
                let athleteID = selectedAthlete.id
                // to use a URL, we need to convert string to URL
                
                if selectedAthlete.id == "124" {
                        Image("Sebastien")
                        .resizable()
                        .scaledToFill()
                        .frame(width:300, height: 300)
                        .clipShape(RoundedRectangle(cornerRadius: 50))
                }
                else{
                    let imageURL = URL(string: baseURL + String (athleteID) + endURL)
                    AsyncImage (url: imageURL) { phase in
                        if let image = phase.image {
                            image
                                .resizable()
                                .scaledToFill()
                                .frame(width: 300, height: 300)
                                .clipShape(RoundedRectangle(cornerRadius: 40))
                        } else {
                            ProgressView()
                        }
                    }
                }
                
                VStack{
                    HStack{
                        Spacer()
                        if selectedAthlete.starter {
                            Image(systemName: "s.circle.fill")
                                .font(.system(size: 60))
                                .foregroundStyle(.white, .blue)
                                .padding(10)
                        }
                    }
                    
                    Spacer()
                    
                    Text(
                        selectedAthlete.firstName
                        + " "
                        + selectedAthlete.lastName
                    )
                    .padding(2)
                    .font(.title)
                    .foregroundColor(.white)
                    .background(Color.blue)
                }
            }
            .frame(width: 300, height: 300)
            
            Text(selectedAthlete.position == "DL" ? "Defensive Lineman" : "Defensive EnD")
                .font(.title) //comment out if not need
            
            //on toggle switch on/off, invoke viewModel intent method to update the starter status
            Text ("Height: " + selectedAthlete.height)
                .font(.title)
            
            Text ("Weight: " + selectedAthlete.weight)
                .font(.title)
            
            
            
            Toggle("Starter", isOn: $isStarter)
                .onChange(of: isStarter) {
                    viewModel.updateAthlete(number: selectedAthlete.number)
                }
            Spacer()
            
        }
        
        .navigationTitle(selectedAthlete.firstName)
        .padding()
    }
}

#Preview {
    @Previewable @State var athletesVM = AthletesViewModel()
    
    var selectedAthlete = AthletesModel.exampleAthlete
    AthleteDetailView (selectedAthlete: selectedAthlete, viewModel: $athletesVM, isStarter: selectedAthlete.starter)
    
    
}

//
//  ContentView.swift
//  MU Football DL Roster List
//
//  Created by Daniel Lezeau on 9/29/26.
//

import SwiftUI

struct AthletesListView: View {
    
    //declared property
    @State private var athletesVM = AthletesViewModel()
    
    //MARK: - computed property
    
    var body: some View {
        NavigationStack{
            
            List(athletesVM.athletesModel.athletes) { athlete in
                NavigationLink {
                    AthleteDetailView(
                        selectedAthlete: athlete,
                        viewModel: $athletesVM,
                        isStarter: athlete.starter
                    )
                }label: {
                    AthleteRowView(athletes: athlete)
                }
                .listRowSeparatorTint(.blue)
            }
            .navigationTitle("2026 MU Defesnisve Line")
            
        }
        //.searchable(text: $searchText)
    }
}

#Preview {
    AthletesListView()
}

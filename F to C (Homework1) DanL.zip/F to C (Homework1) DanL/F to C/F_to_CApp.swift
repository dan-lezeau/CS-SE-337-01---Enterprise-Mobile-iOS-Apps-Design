//
//  F_to_CApp.swift
//  F to C
//
//  Created by Daniel Lezeau on 9/15/26.
//

import SwiftUI

@main
struct F_to_CApp: App {
    var body: some Scene {
        WindowGroup {
            TemperatureView()
        }
    }
}

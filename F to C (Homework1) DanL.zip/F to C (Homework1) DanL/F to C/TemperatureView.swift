//
//  ContentView.swift
//  F to C
//
//  Created by Daniel Lezeau on 9/15/26.
//

import SwiftUI

struct TemperatureView: View {
    @State private var temperatureF = ""
    @State private var temperatureC = "??"
    @State private var temperatureCInput = ""
    @State private var temperatureFOutput = "??"
    
    enum TemperatureUnits {
        case fahrenheit
        case celsius
    }
    
    func convert (_ inputTemperature: String, to: TemperatureUnits) -> String{
        switch (to) {
        case .celsius:
            if let temperature = Double(inputTemperature) {
                let celcius = (temperature - 32) * 5/9
                let result = String(format: "%.2f",celcius)
                return result
            }
            
        case .fahrenheit:
            if let temperature = Double(inputTemperature){
                let fahrenheit = (temperature * 9/5) + 32
                let result = String(format: "%.2f", fahrenheit)
                return result
            }
            //print ("I need to the conversion here from C to F")
            
            let result = ""
            return result
        }
        return " "
        
    }
    
    var body: some View {
        VStack {
            Text ("Temperature Conversion")
                .font(.largeTitle)
            HStack{
                Text("Fahrenheit")
                TextField("",text:$temperatureF)
                Button("To ºC") {
                    temperatureC = convert(temperatureF, to: .celsius )
                    
                }
                .buttonBorderShape(.capsule)
                .buttonStyle(.borderedProminent)
            }
            
        }
        .padding()
        
        HStack{
            Text("Celsius: ")
            Text(temperatureC)
            
        }
        
        HStack{
            Text("Celsius")
            TextField("", text: $temperatureCInput)
            Button("To ºF") {
                temperatureFOutput = convert(temperatureCInput, to: .fahrenheit)
            }
            .buttonBorderShape(.capsule)
            .buttonStyle(.borderedProminent)
        }
        .padding()
    
        HStack{
            Text("Fahrenheit: ")
            Text(temperatureFOutput)
        }
        Spacer()
    }
    

}


#Preview {
    TemperatureView()
}

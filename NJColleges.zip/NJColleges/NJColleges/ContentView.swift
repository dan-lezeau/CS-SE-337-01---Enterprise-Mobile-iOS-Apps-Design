//
//  ContentView.swift
//  NJColleges
//
//  Created by Daniel Lezeau on 10/20/26.
//

import SwiftUI

struct ContentView: View {
//    @State private var collegesVM = CollegesVM()
    
//    var body: some View {
//        Text("Colleges loaded: \(collegesVM.colleges.count)")
//

    var body: some View {
        TabView {
            Tab("Summary", systemImage: "chart.bar") {
                SummaryView()
            }
            Tab("Colleges", systemImage: "list.bullet") {
                CollegeListView()
            }
            Tab("Map", systemImage: "map") {
                CollegeMapView()
            }
        }
    }
}

#Preview {
    ContentView()
}

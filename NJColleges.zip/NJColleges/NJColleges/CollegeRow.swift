//
//  CollegeRow.swift
//  NJColleges
//
//  Created by Daniel Lezeau on 10/20/26.
//

import SwiftUI

struct CollegeRow: View {
    let college: College
    var body: some View {
        VStack(alignment: .leading) {
            Text(college.properties.name)
                .font(.headline)
            HStack {
                Text(college.properties.city)
                Spacer()
                Text(college.properties.county)
            }
            
            
        }
    }
}

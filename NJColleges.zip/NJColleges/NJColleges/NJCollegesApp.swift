//
//  NJCollegesApp.swift
//  NJColleges
//
//  Created by Daniel Lezeau on 10/20/26.
//

import SwiftUI

@main
struct NJCollegesApp: App {
    //One shared ViewModel for every tab (dependency injection).
    @State private var collegesVM = CollegesVM()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(collegesVM)
        }
    }
}

//
//  Untitled.swift
//  NJColleges
//
//  Created by Daniel Lezeau on 10/20/26.
//

import SwiftUI

struct CollegeListView: View {
    
    @State var collegesVM = CollegesVM()
    @State var searchText: String = ""
    
    var body: some View {
        NavigationStack {
            List (searchResults) {college in NavigationLink(destination: CollegeDetailView(college: college)) {
                CollegeRow(college: college)
            }
            .navigationTitle("Colleges")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $searchText)
            }
        }
    }
    
    var searchResults: [College] {
        if searchText.isEmpty {
            return collegesVM.colleges
        } else {
            return collegesVM.colleges.filter {searchFilter(college: $0)}
        }
    }
    
    func searchFilter (college: College) -> Bool {
        return college.properties.name.lowercased().contains(searchText.lowercased())
        || college.properties.county.lowercased().contains(searchText.lowercased())
    }
}
    
    #Preview {
        CollegeListView()
    }

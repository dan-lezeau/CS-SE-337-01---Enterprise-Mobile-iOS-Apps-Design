//
//  CollegeMapView.swift
//  NJColleges
//
//  Created by Daniel Lezeau on 10/20/26.
//

import SwiftUI
import MapKit

struct CollegeMapView: View {
    @Environment(CollegesVM.self) private var collegesVM
    @State private var locationManager = LocationManager()
    @State var selectedCollege: College?
    
    var body: some View {
        Map() {
            UserAnnotation()
            ForEach(collegesVM.colleges) {
                college in
                Annotation(college.properties.name,
                           coordinate: college.geometry.coordinate) {
                    
                    Image(systemName: "graduationcap.circle.fill")
                        .font(.title)
                        .onTapGesture { selectedCollege = college }
                }
            }
        }
        
        //
        .mapControls {
            MapUserLocationButton()
            MapCompass()
            MapPitchToggle()
            MapScaleView()
        }
        
        .mapStyle(.standard)
        .sheet(item: $selectedCollege) { college in
            CollegeDetailView(college: college)
             .presentationDetents([.medium, .large])
             .presentationDragIndicator(.visible)
        }
        //   .task { locationManager.requestPermission() }
        //NavigationStack{
        //   Text("Map")
        //       .navigationTitle("Map")
        
    }
}

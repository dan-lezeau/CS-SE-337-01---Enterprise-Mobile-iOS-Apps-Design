//
//  CollegeDetailView.swift
//  NJColleges
//
//  Created by Daniel Lezeau on 10/20/26.
//

import MapKit
import SwiftUI

struct CollegeDetailView: View {
    let college: College

    var collegeInfo: some View {
        let rows: [(String, String)] = [
            ("Name: ", college.properties.name),
            ("City: ", college.properties.city),
            ("County: ", college.properties.county),
            ("Address: ", college.properties.address),
            ("Phone: ", college.properties.phone),
            ("Zip: ", college.properties.zip)
        ]

        //let properties = Mirror(reflecting: college).children.compactMap {
        //    child -> (String, String)? in

        //     guard let name = child.label else {
        //       return nil
        //    return (name, String(describing: child.value))

        return LazyVGrid(
            columns: [
                GridItem(.flexible()),
                GridItem(.flexible()),
            ],
            alignment: .leading
        ) {
            ForEach(rows, id: \.0) { row in
                Text(row.0)
                    .fontWeight(.semibold)
                Text(row.1)
            }

            .padding()
        }
    }
    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                ScrollView {
                    collegeInfo
                }
                .frame(height: geometry.size.height / 2)

                Map(
                    initialPosition: .region(
                        MKCoordinateRegion(
                            center: CLLocationCoordinate2D(
                                latitude: college.geometry.latitude,
                                longitude: college.geometry.longitude
                            ),
                            span: MKCoordinateSpan(
                                latitudeDelta: 0.01,
                                longitudeDelta: 0.01
                            )
                        )
                    )
                ) {
                    UserAnnotation()
                    Marker(
                        college.properties.name,
                        coordinate: CLLocationCoordinate2D(
                            latitude: college.geometry.latitude,
                            longitude: college.geometry.longitude
                        )
                    )
                }
                .mapControls {

                }
                .mapStyle(.hybrid(elevation: .realistic))
                .frame(height: geometry.size.height / 2)
            }
            .navigationTitle(college.properties.name)
        }
    }
}

#Preview {
    let vm = CollegesVM()
    let college = vm.colleges[0]
    CollegeDetailView(college: college)
}

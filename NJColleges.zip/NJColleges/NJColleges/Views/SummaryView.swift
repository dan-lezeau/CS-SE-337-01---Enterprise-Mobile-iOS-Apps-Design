//
//  SummaryView.swift
//  NJColleges
//
//  Created by Daniel Lezeau on 10/20/26.
//

import SwiftUI

//Summary Tab: counts the colleges by region

struct SummaryView: View {
    @Environment(CollegesVM.self) private var collegesVM
    
    var body: some View {
        NavigationStack {
            List {
                LabeledContent("Total Colleges", value: "\(collegesVM.totalCount)")
                LabeledContent("North Jersey Colleges", value:  "\(collegesVM.northCount)")
                LabeledContent("Central Jersey Colleges", value:  "\(collegesVM.centralCount)")
                LabeledContent("South Jersey Colleges", value: "\(collegesVM.southCount)")
            }
            .navigationTitle("Summary")
        }
    }
}

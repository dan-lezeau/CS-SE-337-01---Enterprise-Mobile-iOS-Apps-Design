//
//  Untitled.swift
//  NJColleges
//
//  Created by Daniel Lezeau on 10/21/26.
//

import Observation

@Observable
class CollegesVM {
    private let collegesModel = CollegeModel()
    var colleges: [College] = []
    
    init() {
        colleges = collegesModel.getColleges()
    }
    
    //Total number of colleges
    var totalCount: Int {
        colleges.count
    }
    
    var northCount: Int {
        colleges.filter {
            $0.geometry.latitude > 40.47368
        }.count
    }
    
    var centralCount: Int {
        colleges.filter {
            $0.geometry.latitude >= 39.95219 && $0.geometry.latitude <= 40.47378
        }.count
    }
        
        var southCount: Int {
            colleges.filter {
                $0.geometry.latitude <= 39.95219
            }.count
    }
    
    
    
    
}

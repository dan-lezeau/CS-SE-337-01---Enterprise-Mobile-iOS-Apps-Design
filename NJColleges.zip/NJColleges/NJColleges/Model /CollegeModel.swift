//
//  CollegeModel.swift
//  NJColleges
//
//  Created by Daniel Lezeau on 10/20/26.
//

import Foundation

class CollegeModel {
    
 //   let data = Data(NJCollegesJsonData.utf(8))

    private var colleges: [College] = []
    
    init() {
        readCollegesData()
    }
    
    func getColleges() -> [College] {
        colleges
    }
    
    func getCollege(collegeId: Int) -> College? {
        colleges.first(where: {$0.id == collegeId})
    }
    
    private func readCollegesData() {
        guard let path = Bundle.main.path(forResource: "NJColleges", ofType: "json") else {
            
            print("file not found")
            return
    }
        do{
            let jsonString = try String(contentsOfFile: path, encoding: .utf8)
            let jsonData = Data(jsonString.utf8)
            colleges = try JSONDecoder().decode([College].self, from: jsonData)
            print("Loaded \(colleges.count) colleges")
        }catch{
            reportDecodingError(error)
        }
    }
    
    private func reportDecodingError(_ error: Error) {
        switch error {
        case DecodingError.keyNotFound(let key, let context):
            print("Missing key '\(key.stringValue)' at path: \(codingPathString(context.codingPath))")
        case DecodingError.typeMismatch(let type, let context):
            print("Type mismatch: expected \(type) at \(codingPathString(context.codingPath))")
        case DecodingError.valueNotFound(let type, let context):
            print("Null value: expected \(type) at \(codingPathString(context.codingPath))")
        case DecodingError.dataCorrupted(let context):
            print("Invalid JSON at \(codingPathString(context.codingPath))")
        case DecodingError.dataCorrupted(let context):
            print("Invalid JSON at \(codingPathString(context.codingPath))")
        default:
            print("Unexpected error: \(error)")
        }
        
    }
    
    private func codingPathString(_ path: [CodingKey]) -> String {
        path.map { $0.intValue.map { "[\($0)]" } ?? ".\($0.stringValue)" }
            .joined()
    }
}

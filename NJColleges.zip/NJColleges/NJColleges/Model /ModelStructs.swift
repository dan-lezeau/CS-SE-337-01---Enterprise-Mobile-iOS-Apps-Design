//
//  ModelStructs.swift
//  NJColleges
//
//  Created by Daniel Lezeau on 10/20/26.

// structures to match JSON
import Foundation
import CoreLocation

struct College: Codable, Identifiable {
    let geometry: CollegeGeometry
    let properties: CollegeProperties
    
    var id: Int { properties.id }
}

struct CollegeGeometry: Codable {
    let coordinates: [Double] // [longitude, latitude]
    
    var longitude: Double { coordinates[0]}
    var latitude: Double {coordinates[1]}
    
    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
}


struct CollegeProperties: Codable, Identifiable {
    
    let name: String
    let county: String
    let municipality: String
    let id: Int
    let address: String
    let phone: String
    let city: String
    let zip: String
    let publicResearch: String
   // var public_res: Bool = false
  //  let coordinates: Double
    
    enum CodingKeys: String, CodingKey{
        case name = "Name"
        case county = "County"
        case municipality = "Municipali"
        case id = "FID"
        case address = "ADDRESS"
        case phone = "PHONE"
        case city = "CITY"
        case zip = "ZIP"
        case publicResearch = "PUBLIC_RES"
    }
}
